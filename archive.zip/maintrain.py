import streamlit as st
st.title("SG lab")
st.header("Brain Tumor Classification")